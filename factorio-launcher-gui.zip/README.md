# factorio-launcher-gui
Just a little launcher Python3 tkinter gui for launching Factorio with different mod sets.

It support Windows and Linux and allowes to set different Mod Paths and game paths, such as Steam natively.

Please note taht you need Python3 and tkinter to run the program.

